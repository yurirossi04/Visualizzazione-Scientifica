import pandas as pd
import matplotlib.pyplot as plt

# Lettura del file CSV
df = pd.read_csv('File csv/incidenti-per-tipo-di-veicoli-coinvolti-e-regione-anni-2001-2018.csv')

# Creazione delle nuove categorie
categories = {
    'Trasporti\nPubblici': ['autobus o filobus servizio urbano', 'autobus servizio extra-urbano', 'tram', 'autosnodato autoarticolato', 'autovettura pubblica'],
    'Autocarri': ['autocarro', 'autotreno con rimorchio', 'autosnodato autoarticolato'],
    'Trattori': ['trattore stradale o motrice', 'trattore agricolo'],
    'Veicolo\nignoto': ['veicolo ignoto datosi alla fuga'],
    'Biciclette': ['velocipede'],
}

for category, columns in categories.items():
    df[category] = df[columns].sum(axis=1)

# Somma totale degli incidenti per categoria
incidenti_per_categoria = df[list(categories.keys())].sum()

# Calcolo delle percentuali
percentuali = (incidenti_per_categoria / incidenti_per_categoria.sum()) * 100

# Creazione del grafico a torta
fig, ax = plt.subplots(figsize=(8, 8))
colors = ['#FFDAB9', '#FFA07A', '#FF7F50', '#FF6347', '#FF4E3E']  # Scala di colori arancione meno saturo
percentuali_sorted = percentuali.sort_values(ascending=True)  # Ordina per assegnare i colori in modo corretto
wedges, texts, autotexts = ax.pie(percentuali_sorted, labels=percentuali_sorted.index, autopct='%1.1f%%', colors=colors, startangle=140)

# Miglior posizionamento delle etichette
for text in texts:
    text.set_fontsize(12)
    text.set_weight("bold")
for autotext in autotexts:
    autotext.set_fontsize(12)
    autotext.set_weight("bold")
    autotext.set_color("black")

ax.set_title('Percentuale di Incidenti per Tipologia di Veicolo', fontsize=14, fontweight='bold')

# Mostrare il grafico
plt.show()
