import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# Carica il dataset
file_path = "File csv/DCIS_INCIDENTISTR1_03022025132214442.csv"
df = pd.read_csv(file_path)

# Rimuovi eventuali spazi indesiderati dai nomi delle colonne
df.columns = df.columns.str.strip()
df = df[df["Intersezione"] != "passaggio a livello"]
df = df[df["Intersezione"] != "totale"]


# Se il file contiene una colonna "Tipo di strada", la usiamo per raggruppare, altrimenti usiamo "Intersezione"
if 'Tipo di strada' in df.columns:
    strada_col = 'Tipo di strada'
else:
    strada_col = 'Intersezione'

# Crea una tabella pivot
pivot_df = df.pivot_table(index=strada_col, 
                          columns='Natura dell incidente', 
                          aggfunc='size', 
                          fill_value=0)

# Rimuovi le colonne "totale" e "passaggio a livello" (senza differenza di maiuscole/minuscole)
pivot_df = pivot_df.loc[:, ~pivot_df.columns.str.lower().isin(['totale', 'passaggio a livello'])]

# Lista di colori personalizzati
colors = ['#064789', '#427aa1', '#99C0EC']

# Crea il grafico a barre orizzontali con i colori personalizzati
ax = pivot_df.plot(kind='barh', stacked=True, figsize=(12, 8), color=colors)

# Imposta le etichette e il titolo
ax.set_ylabel(strada_col, fontsize=12, rotation=0)
ax.set_xlabel('Numero di incidenti', fontsize=12)
ax.set_title('Incidenti per tipo di strada', fontsize=14, fontweight='bold')
plt.legend(title='Natura dell incidente', bbox_to_anchor=(1.05, 1), loc='upper left')

# Formatta l'asse delle x per visualizzare i numeri in migliaia
ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: f'{x/1000:.0f}K'))

# Migliora il layout e mostra il grafico
plt.tight_layout()
plt.show()
