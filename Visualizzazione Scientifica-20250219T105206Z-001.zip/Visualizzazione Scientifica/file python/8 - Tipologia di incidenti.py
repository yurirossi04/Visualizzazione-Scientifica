import pandas as pd
import matplotlib.pyplot as plt

# Lettura del file CSV
df = pd.read_csv('File csv/DCIS_INCIDENTISTR1_03022025132214442.csv')

# Filtra i dati per escludere le righe con "totale" nella colonna "NATURAINCIDENTE"
df_filtrato = df[df['Natura dell incidente'] != 'totale']

# Raggruppamento degli incidenti per la colonna "NATURAINCIDENTE"
incidenti_per_natura = df_filtrato.groupby('Natura dell incidente')['Value'].sum()

# Definizione di una palette di colori personalizzati
colori_personalizzati = ['#6C91C2', '#354674', '#C3C9E9']

# Creazione del grafico a torta
fig, ax = plt.subplots(figsize=(8, 8))
ax.pie(incidenti_per_natura, 
       labels=incidenti_per_natura.index, 
       autopct='%1.1f%%', 
       startangle=90, 
       colors=colori_personalizzati[:len(incidenti_per_natura)])  # Assicura che il numero di colori corrisponda al numero di categorie

# Titolo del grafico
ax.set_title('Distribuzione degli Incidenti Stradali per Natura dell\'Incidente')

# Mostrare il grafico
plt.show()