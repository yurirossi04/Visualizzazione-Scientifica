import pandas as pd
import matplotlib.pyplot as plt

# Caricamento del dataset
df = pd.read_csv('File csv/morti_europa_per_tipologia.csv')

# Rimuove eventuali spazi nei nomi delle colonne
df.columns = df.columns.str.strip()

# Assicura che la colonna "totale" sia numerica
df['totale'] = pd.to_numeric(df['totale'], errors='coerce')

# Mantiene l'ordine originale del file CSV
df['ordine'] = df.index  # Salva l'ordine originale

# Dizionario per la conversione delle sigle in nomi completi
dict_nomi_paesi = {
    "IT": "Italia", "FR": "Francia", "DE": "Germania", "ES": "Spagna", "AT": "Austria", "CH": "Svizzera", "SI": "Slovenia", "HR": "Croazia"
}

df['paese_nome'] = df['paese'].map(dict_nomi_paesi).fillna(df['paese'])

# Raggruppa per paese e somma il totale dei morti
df_grouped = df.groupby(['paese', 'paese_nome'], as_index=False).agg({'totale': 'sum', 'ordine': 'first'})

# Riordina i dati in base all'ordine originale nel CSV e resetta l'indice
df_grouped = df_grouped.sort_values(by='ordine').reset_index(drop=True)

# Trova i 2 paesi con il massimo numero di morti
top_countries = df_grouped.nlargest(2, 'totale')

# Paesi da evidenziare con un colore diverso (Slovenia, Austria, Croazia)
highlight_countries = df_grouped[df_grouped['paese'].isin(["IT", "FR", "AT", "CH", "SI", "DE", "HR"])]

# Creazione del grafico lollipop
plt.figure(figsize=(12, 6))
plt.hlines(y=df_grouped['paese'], xmin=0, xmax=df_grouped['totale'], color='#ACCDF3', linewidth=4, alpha=0.5)
plt.scatter(df_grouped['totale'], df_grouped['paese'], color='#ACCDF3', s=120, zorder=3)

# Evidenziazione dei paesi di interesse
for _, row in highlight_countries.iterrows():
    if row['paese'] == "IT":
        color = '#F7483B'  # Colore per l'Italia
    elif row['paese'] in top_countries['paese'].values:
        color = '#183E6A'  # Colore per i 2 paesi con il numero massimo di morti
    else:
        color = '#6C97C9'  # Colore per Slovenia, Austria e Croazia (e gli altri paesi di interesse)

    plt.hlines(y=row['paese'], xmin=0, xmax=row['totale'], color=color, linewidth=4, alpha=0.5)
    plt.scatter(row['totale'], row['paese'], color=color, s=120, zorder=3)
    plt.text(row['totale'] + (df_grouped['totale'].max() * 0.02), row['paese'], row['paese_nome'], color=color, fontsize=12, fontweight='normal', va='center')

# Migliora l'aspetto del grafico
plt.xlabel("Numero Totale di Morti", fontsize=12)
plt.ylabel("Paese", fontsize=12)
plt.title("Numero Totale di Morti per Paese - Grafico Lollipop", fontsize=14, fontweight="bold")
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.xlim(0, df_grouped['totale'].max() * 1.1)  # Assicura che l'origine degli assi coincida

plt.show()
