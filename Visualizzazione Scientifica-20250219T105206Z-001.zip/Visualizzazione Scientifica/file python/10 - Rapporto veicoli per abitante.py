import pandas as pd
import matplotlib.pyplot as plt

# Caricare il dataset
file_path = "File csv/popolazione_auto.csv"
df = pd.read_csv(file_path)

# Convertire le colonne numeriche da stringa a intero, rimuovendo eventuali separatori di migliaia
df["Popolazione"] = df["Popolazione"].str.replace(".", "").astype(int)
df["Totale Veicoli"] = df["Totale Veicoli"].str.replace(".", "").astype(int)

# Calcolare il numero di veicoli per abitante per ogni regione
df["Veicoli per Abitante"] = df["Totale Veicoli"] / df["Popolazione"]

# Creare il grafico a barre
plt.figure(figsize=(12, 8))
plt.barh(df["Regione"], df["Veicoli per Abitante"], color="lightgreen")
plt.xlabel("Veicoli per Abitante")
plt.ylabel("Regione")
plt.title("Veicoli per abitante di ogni regione", fontweight='bold')
plt.gca().invert_yaxis()  # Invertire l'asse Y per avere la regione con più veicoli in alto
plt.show()
