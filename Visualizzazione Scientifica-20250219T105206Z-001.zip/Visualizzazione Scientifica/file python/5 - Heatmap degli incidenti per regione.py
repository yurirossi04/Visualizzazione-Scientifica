import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import json
import requests
from matplotlib.colors import Normalize
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.ticker import FuncFormatter

# Lettura del file CSV
df = pd.read_csv('File csv/DCIS_INCIDENTISTR1_03022025132214442.csv')
regioni = [
    'Abruzzo', 'Basilicata', 'Calabria', 'Campania', 'Emilia-Romagna',
    'Friuli-Venezia Giulia', 'Lazio', 'Liguria', 'Lombardia', 'Marche', 
    'Molise', 'Piemonte', 'Puglia', 'Sardegna', 'Sicilia', 'Toscana', 
    'Trentino Alto Adige / Südtirol', 'Umbria', "Valle d'Aosta / Vallée d'Aoste", 'Veneto'
]

# Filtraggio delle righe che contengono solo le regioni specificate
df_regioni = df[df['Territorio'].isin(regioni)]

# Raggruppamento per regione e somma degli incidenti
incidenti_per_regione = df_regioni.groupby('Territorio')['Value'].sum()

# Convertire i valori in decine di migliaia
incidenti_per_regione = incidenti_per_regione / 10000

# Scaricamento dei dati geojson dell'Italia
url = "https://raw.githubusercontent.com/openpolis/geojson-italy/master/geojson/limits_IT_regions.geojson"
response = requests.get(url)
italia_geojson = response.json()

# Creazione della figura
fig, ax = plt.subplots(figsize=(8, 12))

# Creazione di una mappa di colori basata sui valori reali
vmin, vmax = incidenti_per_regione.min(), incidenti_per_regione.max()
norm = Normalize(vmin=vmin, vmax=vmax)
cmap = plt.cm.Blues  # Colori da azzurro a blu

# Disegnare le regioni
for feature in italia_geojson['features']:
    regione_nome = feature['properties']['reg_name']
    if regione_nome in incidenti_per_regione:
        valore = incidenti_per_regione[regione_nome]
        color = cmap(norm(valore))
    else:
        color = "#dddddd"  # Grigio per regioni senza dati
    
    geometry = feature['geometry']
    
    # Estrarre tutte le coordinate per calcolare il centroido
    all_coords = []
    
    if geometry['type'] == 'Polygon':
        for polygon in geometry['coordinates']:
            all_coords.extend(polygon)
            ax.fill(*zip(*polygon), color=color, edgecolor='black', linewidth=0.8)
    elif geometry['type'] == 'MultiPolygon':
        for multipolygon in geometry['coordinates']:
            for polygon in multipolygon:
                all_coords.extend(polygon)
                ax.fill(*zip(*polygon), color=color, edgecolor='black', linewidth=0.8)

# Creazione della barra dei colori basata su valori assoluti
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)

# Creazione di un formato personalizzato per la barra dei colori
def thousands_formatter(x, pos):
    return f'{int(x)}k'  # Convertire in '10k', '100k', ecc.

# Creare la barra dei colori
cbar = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax)
cbar.ax.yaxis.set_major_formatter(FuncFormatter(thousands_formatter))  # Applicare il formato personalizzato

# Ruotare l'etichetta della barra dei colori in orizzontale
cbar.ax.yaxis.label.set_rotation(0)

# Personalizzazione
title = "Numero di Incidenti Stradali per Regione"
ax.set_title(title, fontdict={'fontsize': 15, 'fontweight': 'bold'})
ax.axis("off")

# Mostrare la mappa
plt.show()
