import pandas as pd
import matplotlib.pyplot as plt
from numpy import polyfit

# Caricamento del dataset
file_path = "File csv/morti_negli_anni_europa.csv"
df = pd.read_csv(file_path)

# Assicuriamoci che la colonna "Paese" sia l'indice
df.set_index("Paese", inplace=True)

# Verifica che i dati siano numerici (potresti avere valori non numerici come stringhe)
df = df.apply(pd.to_numeric, errors='coerce')  # Converte i valori non numerici in NaN

# Rimuovere le ultime due colonne
df = df.iloc[:, :-2]  # Seleziona tutte le colonne tranne le ultime due

# Rimuovere i paesi che hanno almeno un valore NaN (mancante) in una colonna
df = df.dropna()

# Applicare il valore assoluto a tutte le colonne
df = df.abs()  # Converte tutti i valori negativi in positivi

# Somma dei morti per ogni paese
total_deaths = df.sum(axis=1)

# Selezionare i 7 paesi con più morti
top_7 = total_deaths.nlargest(7)  # 7 paesi con più morti

# Filtrare il DataFrame per i paesi selezionati
df_selected = df.loc[top_7.index]

# Calcolare la mediana per ogni anno
median_line = df_selected.median(axis=0)

# Calcolare la pendenza e l'intercetta della retta di regressione (linea retta per la mediana)
years = range(len(median_line))  # Assegna un numero agli anni (indici delle colonne)
slope, intercept = polyfit(years, median_line, 1)  # Calcola la pendenza e l'intercetta

# Creare la linea retta della mediana
line_fit = [slope * x + intercept for x in years]

# Stampa i valori filtrati che verranno usati nel grafico
print("\nValori selezionati per il grafico (Top 7):")
print(df_selected)

# Creazione della figura (figsize) separata per il grafico
plt.figure(figsize=(12, 6))

# Definiamo i colori manualmente per ogni paese
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']  # Colori a tua scelta

# Creazione del grafico a linee con i dati reali, usando i colori specificati
# Assegna etichette personalizzate ai paesi
labels_paesi = ["Turchia", "Francia", "Germania", "Italia", "Polonia", "Spagna", "Romania"]
df_selected.T.plot(kind="line", marker='o', alpha=0.3, figsize=(12, 6), color=colors, label=labels_paesi)

# Aggiungere la linea della mediana come una linea retta con etichetta personalizzata
plt.plot(df_selected.columns, line_fit, label="Tendenza", color="black", alpha=0.8, linewidth=2)

# Aggiunta del titolo e delle etichette degli assi
plt.title("Numero di morti per Paese negli anni", fontweight='bold')
plt.xlabel("Anno")
plt.ylabel("Numero di morti")

# Personalizzazione della legenda con etichette personalizzate
plt.legend(title="Legenda", loc="upper right", labels=labels_paesi + ["Mediana"])

# Visualizzazione del grafico
plt.show()
