import matplotlib.pyplot as plt
import pandas as pd
import json
import requests
import matplotlib as mpl

# Caricare la mappa dell'Italia da GeoJSON
url = "https://raw.githubusercontent.com/openpolis/geojson-italy/master/geojson/limits_IT_regions.geojson"
response = requests.get(url)
italy_map = json.loads(response.text)

# Caricare i dati dal file CSV usando pandas
df = pd.read_csv("/home/mozgus/Scaricati/Veicoli - Pubblico registro automobilistico.csv", encoding='latin1')

# Creare un dizionario con la colonna "Regione" e "Totale"
region_data = dict(zip(df['Territorio'], df['Totale']))

# Dividere per 1.000.000 per avere i valori in milioni
region_data_in_millions = {k: v / 1_000_000 for k, v in region_data.items()}

# Definire un array con le regioni da considerare
selected_regions = [ 'Abruzzo', 'Basilicata', 'Calabria', 'Campania', 'Emilia-Romagna',
    'Friuli-Venezia Giulia', 'Lazio', 'Liguria', 'Lombardia', 'Marche', 
    'Molise', 'Piemonte', 'Puglia', 'Sardegna', 'Sicilia', 'Toscana', 
    'Trentino-Alto Adige/Südtirol', 'Umbria', "Valle d'Aosta/Vallée d'Aoste", 'Veneto']

# Creare la figura
fig, ax = plt.subplots(figsize=(10, 12))

# Creare un oggetto colormap per la visualizzazione
cmap = plt.cm.OrRd

# Valore massimo della colorbar
max_value = 10  # Impostato a 10 milioni

# Disegnare le regioni
for feature in italy_map["features"]:
    regione = feature["properties"]["reg_name"]
    
    # Debug: stampare tutti i nomi delle regioni presenti nel GeoJSON
    print(f"Regione trovata nel GeoJSON: {regione}")
    
    if regione in selected_regions or "Trentino" in regione:
        print(f"Disegnando: {regione}")  # Debug per verificare che venga disegnata
        coordinates = feature["geometry"]["coordinates"]
        valore = region_data_in_millions.get(regione, 0)
        color = cmap(valore / max_value) if region_data_in_millions else "#cccccc"
        
        # Gestione delle geometrie di tipo Polygon, MultiPolygon e Point
        if feature["geometry"]["type"] == "Polygon":
            for polygon in coordinates:
                x, y = zip(*polygon)
                ax.fill(x, y, color=color, edgecolor='black', linewidth=0.8)
        elif feature["geometry"]["type"] == "MultiPolygon":
            for multi_polygon in coordinates:
                for polygon in multi_polygon:
                    x, y = zip(*polygon)
                    ax.fill(x, y, color=color, edgecolor='black', linewidth=0.8)
        elif feature["geometry"]["type"] == "Point":
            if len(coordinates) > 0:
                x, y = coordinates[0]
                ax.plot(x, y, marker='o', color=color, markersize=5)

# Aggiungere la colorbar (legenda)
sm = mpl.cm.ScalarMappable(cmap=cmap, norm=mpl.colors.Normalize(vmin=0, vmax=max_value))
sm.set_array([])
cbar = fig.colorbar(sm, ax=ax)
cbar.set_label('Valore (milioni)', rotation=270, labelpad=20)

# Rimuovere assi
ax.set_xticks([])
ax.set_yticks([])
ax.set_frame_on(False)
ax.set_title("Veicoli per regione", fontsize=12)

# Mostrare la mappa
plt.show()
