import pandas as pd
import matplotlib.pyplot as plt

# Caricamento del dataset
file_path = "File csv/morti_negli_anni_europa.csv"
df = pd.read_csv(file_path)

# Assicuriamoci che la colonna "Paese" sia l'indice
df.set_index("Paese", inplace=True)

# Converte le colonne in numerico, rimuove valori non validi
df = df.apply(pd.to_numeric, errors='coerce').dropna().abs()

# Rimuovere le ultime due colonne
df = df.iloc[:, :-2]  # Seleziona tutte le colonne tranne le ultime due

# Somma dei morti per ogni paese e seleziona i 7 con più morti
top_7 = df.sum(axis=1).nlargest(7)
df_selected = df.loc[top_7.index]

# Dizionario con i nomi estesi dei paesi
nomi_paesi = {
    "TR": "Turchia",
    "FR": "Francia",
    "DE": "Germania",
    "IT": "Italia",
    "PL": "Polonia",
    "ES": "Spagna",
    "RO": "Romania"
}

# Creazione della figura
plt.figure(figsize=(12, 6))

# Disegna tutte le linee in grigio (tranne IT)
for paese in df_selected.index:
    if paese != "IT":
        df_selected.loc[paese].T.plot(
            kind="line", marker='o', alpha=0.8, linewidth=1, color='#A0A0A0', 
            label=nomi_paesi.get(paese, paese)  # Usa il nome esteso se presente, altrimenti lascia l'acronimo
        )

# Disegna la linea dell'Italia sopra le altre
if "IT" in df_selected.index:
    df_selected.loc["IT"].T.plot(
        kind="line", marker='o', alpha=0.8, linewidth=2, color='#d62728', 
        label=nomi_paesi["IT"]  # Nome esteso per l'Italia
    )

# Titolo e etichette
plt.title("Numero di morti per Paese negli anni", fontweight='bold')
plt.xlabel("Anno")
plt.ylabel("Numero\nmorti", rotation=0)

# Personalizzazione della legenda con i nomi estesi
plt.legend(title="Legenda", loc="upper right")

# Mostra il grafico
plt.show()