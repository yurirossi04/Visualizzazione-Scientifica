import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Caricare i dati dal CSV
df = pd.read_csv("File csv/DCIS_INCIDENTISTR1_03022025132214442_giorni.csv")

# Contare gli incidenti per mese
incidenti_per_mese = df['Giorno della settimana'].value_counts()

# Ordinare i mesi dell'anno
giorni_settimana = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica']
incidenti_per_giorno = incidenti_per_mese[giorni_settimana]

# Creare il grafico a barre
plt.figure(figsize=(10,6))
incidenti_per_giorno.plot(kind='bar', color='lightgreen')
plt.title('Incidenti Stradali per Giorno', fontweight='bold')

plt.ylim(2500, 3200)  # Sostituisci 1000 con il valore massimo desiderato


# Ruotare le etichette dei mesi sull'asse x
plt.xticks(rotation=0)
plt.tight_layout()

# Mostrare il grafico
plt.show()
