import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, RegularPolygon
from matplotlib.path import Path
from matplotlib.projections.polar import PolarAxes
from matplotlib.projections import register_projection
from matplotlib.spines import Spine
from matplotlib.transforms import Affine2D
from matplotlib.lines import Line2D

# Funzione per creare il radar chart
def radar_factory(num_vars, frame='circle'):
    theta = np.linspace(0, 2 * np.pi, num_vars, endpoint=False)
    
    class RadarTransform(PolarAxes.PolarTransform):
        def transform_path_non_affine(self, path):
            if path._interpolation_steps > 1:
                path = path.interpolated(num_vars)
            return Path(self.transform(path.vertices), path.codes)

    class RadarAxes(PolarAxes):
        name = 'radar'
        PolarTransform = RadarTransform

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.set_theta_zero_location('N')
            self.set_ylim(0, 1)

        def fill(self, *args, closed=True, **kwargs):
            return super().fill(closed=closed, *args, **kwargs)

        def plot(self, *args, **kwargs):
            lines = super().plot(*args, **kwargs)
            for line in lines:
                self._close_line(line)

        def _close_line(self, line):
            x, y = line.get_data()
            if x[0] != x[-1]:
                x = np.concatenate((x, [x[0]]))
                y = np.concatenate((y, [y[0]]))
                line.set_data(x, y)

        def set_varlabels(self, labels):
            self.set_thetagrids(np.degrees(theta), labels)

        def _gen_axes_patch(self):
            if frame == 'circle':
                return Circle((0.5, 0.5), 0.5)
            elif frame == 'polygon':
                return RegularPolygon((0.5, 0.5), num_vars, radius=0.5, edgecolor="k")
            else:
                raise ValueError("unknown value for 'frame': %s" % frame)

        def draw(self, renderer):
            if frame == 'polygon':
                gridlines = self.yaxis.get_gridlines()
                for gl in gridlines:
                    gl.get_path()._interpolation_steps = num_vars
            super().draw(renderer)

        def _gen_axes_spines(self):
            if frame == 'circle':
                return super()._gen_axes_spines()
            elif frame == 'polygon':
                spine = Spine(axes=self, spine_type='circle', path=Path.unit_regular_polygon(num_vars))
                spine.set_transform(Affine2D().scale(.5).translate(.5, .5) + self.transAxes)
                return {'polar': spine}
            else:
                raise ValueError("unknown value for 'frame': %s" % frame)

    register_projection(RadarAxes)
    return theta

# Caricare i dati dal CSV
file_path = "File csv/multe_per_tipo_2023.csv"
df = pd.read_csv(file_path, sep=';')

# Selezionare le colonne interessate e ordinare per Totale decrescente
df = df.sort_values(by="Totale", ascending=False).head(8)
categories = df["Tipo_Contravvenzione"].tolist()[3:]
values = df["Totale"].astype(float).tolist()[3:]

# Definisci i colori personalizzati per i pallini
custom_colors = ['#8bc34a', '#ffc107', '#ff9800', '#f44336', '#ad1457']  

# Calcolare il massimo valore e normalizzare i valori
max_value = max(values)
print(max_value)
normalized_values = [v / max_value for v in values]

# Impostare i valori personalizzati per le griglie radiali (valori da 0.5M a 5M)
custom_rgrid_values = [50000, 100000, 150000, 200000, 250000, 300000]  # In milioni

# Creare il radar chart
N = len(categories)
print(N)
theta = radar_factory(N, frame='polygon')

fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(projection='radar'))
fig.subplots_adjust(top=0.85, bottom=0.05)
ax.set_varlabels(categories)

# Impostare la griglia radiale con i valori personalizzati
rgrid_values = [value / max_value for value in custom_rgrid_values]  # Normalizzare per il grafico

# Usare il formato float per le etichette della griglia
ax.set_rgrids(rgrid_values, labels=[f"{v/1_000:.0f}K" for v in custom_rgrid_values], angle=0)

# Spostare le etichette delle griglie fuori dalla figura
ax.set_rlabel_position(72)  # Posizione delle etichette radiali (180 gradi per spostarle a sinistra)

# Disegnare prima l'area riempita del radar chart con un grigio più scuro
ax.fill(theta, normalized_values, color='grey', alpha=0.4)  # Riempimento più scuro e trasparente
ax.plot(theta, normalized_values, color='grey', linewidth=1)  # Outline nero per contrasto

# Disegnare i pallini sopra all'area già riempita con colori personalizzati
sc = ax.scatter(theta, normalized_values, c=custom_colors, s=60, label=categories, zorder=3)

# Creare la legenda manualmente
legend_elements = [Line2D([0], [0], marker='o', color='w', label=cat,
                          markerfacecolor=col, markersize=8) 
                   for cat, col in zip(categories, custom_colors)]

ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.3, 1))

# Rimuovere le scritte degli angoli
ax.set_xticklabels([])

plt.title("Multe per tipologie", fontweight='bold')

plt.show()
