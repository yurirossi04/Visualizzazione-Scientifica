import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

# Lettura del file CSV
df = pd.read_csv('File csv/DCIS_INCIDENTISTR1_03022025132214442.csv')

# Estrazione degli incidenti per ogni ora (dalla colonna "ORA")
df['ORA'] = df['ORA'].astype(int)
incidenti_per_ora = df.groupby('ORA')['Value'].sum()

# Creazione della figura
fig, ax = plt.subplots(figsize=(15, 8))

# Posizione delle barre (da 1 a 24)
x = np.arange(1, 25)

# Creazione di una lista di colori
colors = ['lightgreen' if ora not in [13, 18] else 'green' for ora in x]

# Plot degli incidenti per ora
ax.bar(x, incidenti_per_ora.reindex(x, fill_value=0), color=colors, label='Incidenti')

# Personalizzazione del grafico
ax.set_xlabel('Ora del Giorno')
ax.set_title('Incidenti Stradali per Ora del Giorno', fontweight='bold')
ax.set_xticks(x)
ax.legend()

# Funzione per formattare i tick in migliaia
def format_migliaia(x, pos):
    return f'{x / 10000:.1f}k'  # Formattiamo i valori in migliaia, con un decimale

# Applicazione del formatter ai ticks sull'asse y
ax.yaxis.set_major_formatter(FuncFormatter(format_migliaia))

# Miglioramento valori asse y
ax.yaxis.set_major_locator(plt.MaxNLocator(integer=True))
ax.tick_params(axis='y', which='both', left=True, right=False, labelleft=True)

plt.show()
