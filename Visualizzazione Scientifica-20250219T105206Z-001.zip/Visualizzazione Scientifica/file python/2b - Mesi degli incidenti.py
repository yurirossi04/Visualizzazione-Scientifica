import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Caricare i dati dal CSV
df = pd.read_csv("File csv/DCIS_INCIDENTISTR1_03022025132214442.csv")

# Contare gli incidenti per mese
incidenti_per_mese = df['Mese'].value_counts()

# Ordinare i mesi dell'anno
mesi_anno = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 
             'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre']
incidenti_per_mese = incidenti_per_mese[mesi_anno]

# Definire i colori (più saturo per luglio)
colors = ['lightgreen' if mese != 'luglio' else 'green' for mese in mesi_anno]

# Creare il grafico a barre
plt.figure(figsize=(10,6))
incidenti_per_mese.plot(kind='bar', color=colors)
plt.title('Incidenti Stradali per Mese', fontweight='bold')

# Personalizzare la visualizzazione dei valori sull'asse y in migliaia
def format_migliaia(x, pos):
    return f'{int(x / 10000)}k'  # Dividere per 10000 e aggiungere 'k'

plt.gca().yaxis.set_major_formatter(FuncFormatter(format_migliaia))

# Ruotare le etichette dei mesi sull'asse x
plt.xticks(rotation=0)
plt.tight_layout()

# Mostrare il grafico
plt.show()
