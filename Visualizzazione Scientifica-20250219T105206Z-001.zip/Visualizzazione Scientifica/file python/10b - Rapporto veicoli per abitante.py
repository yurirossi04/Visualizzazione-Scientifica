import pandas as pd
import matplotlib.pyplot as plt

# Caricare il dataset
file_path = "File csv/popolazione_auto.csv"
df = pd.read_csv(file_path)

# Convertire le colonne numeriche da stringa a intero, rimuovendo eventuali separatori di migliaia
df["Popolazione"] = df["Popolazione"].str.replace(".", "").astype(int)
df["Totale Veicoli"] = df["Totale Veicoli"].str.replace(".", "").astype(int)

# Calcolare il numero di veicoli per abitante per ogni regione
df["Veicoli per Abitante"] = df["Totale Veicoli"] / df["Popolazione"]

# Creare una lista di colori: grigio per tutte le regioni, rosso per la Valle d'Aosta
colors = ["lightgreen" if regione != "Valle d'Aosta" and regione != "Trentino-Alto Adige" else "green" for regione in df["Regione"]]

# Creare il grafico a barre orizzontali
plt.figure(figsize=(12, 8))
plt.barh(df["Regione"], df["Veicoli per Abitante"], color=colors)
plt.xlabel("Veicoli per Abitante")
plt.ylabel("Regione")
plt.title("Veicoli per abitante di ogni regione", fontweight='bold')
plt.gca().invert_yaxis()  # Invertire l'asse Y per avere la regione con più veicoli in alto

# Mostrare il grafico
plt.show()
