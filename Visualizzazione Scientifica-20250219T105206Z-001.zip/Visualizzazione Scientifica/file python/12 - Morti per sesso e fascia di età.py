import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Caricamento dei dati dai file CSV
df_2023 = pd.read_csv("File csv/morti_feriti_per_sesso_2013.csv")
df_2013 = pd.read_csv("File csv/morti_feriti_per_sesso_2023.csv")

# Selezioniamo solo le righe pari (indici pari nel DataFrame)
df_2023 = df_2023.iloc[0::2]
df_2013 = df_2013.iloc[0::2]

# Calcolo della somma totale delle morti per ciascun anno
totale_morti_2023 = df_2023['morti TOT'].sum()
totale_morti_2013 = df_2013['morti TOT'].sum()

# Creazione delle percentuali
df_2023['Percentuale Maschi'] = (df_2023['morti M'] / totale_morti_2023) * 100
df_2023['Percentuale Femmine'] = (df_2023['morti F'] / totale_morti_2023) * 100

df_2013['Percentuale Maschi'] = (df_2013['morti M'] / totale_morti_2013) * 100
df_2013['Percentuale Femmine'] = (df_2013['morti F'] / totale_morti_2013) * 100

# Funzione per formattare i tick in percentuale
def percent_formatter(x, pos):
    return f'{abs(x):.1f}%'  # Usa il valore assoluto per evitare segni negativi

# Creazione del grafico
fig, ax = plt.subplots(figsize=(12, 7))

# Disegno delle barre per il 2023 (colorate)
ax.barh(df_2023['classi di età'], df_2023['Percentuale Maschi'], color='lightblue', label='Maschi 2023', align='center')
ax.barh(df_2023['classi di età'], -df_2023['Percentuale Femmine'], color='pink', label='Femmine 2023', align='center')

# Disegno delle barre per il 2013 (solo contorno)
ax.barh(df_2013['classi di età'], df_2013['Percentuale Maschi'], color='none', edgecolor='blue', linewidth=1, label='Maschi 2013', align='center')
ax.barh(df_2013['classi di età'], -df_2013['Percentuale Femmine'], color='none', edgecolor='magenta', linewidth=1, label='Femmine 2013', align='center')

# Aggiungiamo etichette e titolo
ax.set_xlabel('Percentuale di Morti (%)')
ax.set_title('Percentuali dei morti per sesso e fasce di età', fontweight='bold')

# Impostiamo i limiti dell'asse x per mantenere la simmetria
ax.set_xlim(-20, 20)

# Formattiamo i tick dell'asse x in percentuale
ax.xaxis.set_major_formatter(FuncFormatter(percent_formatter))

# Aggiungiamo una legenda
ax.legend()

# Mostriamo il grafico
plt.tight_layout()
plt.show()
