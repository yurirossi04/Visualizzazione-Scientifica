import pandas as pd
import matplotlib.pyplot as plt

# Caricamento del dataset
file_path = "File csv/morti_negli_anni_europa.csv"
df = pd.read_csv(file_path)

# Assicuriamoci che la colonna "Paese" sia l'indice
df.set_index("Paese", inplace=True)

# Verifica che i dati siano numerici (potresti avere valori non numerici come stringhe)
df = df.apply(pd.to_numeric, errors='coerce')  # Converte i valori non numerici in NaN

# Rimuovere le ultime due colonne
df = df.iloc[:, :-2]  # Seleziona tutte le colonne tranne le ultime due

# Rimuovere i paesi che hanno almeno un valore NaN (mancante) in una colonna
df = df.dropna()

# Applicare il valore assoluto a tutte le colonne
df = df.abs()  # Converte tutti i valori negativi in positivi

# Somma dei morti per ogni paese
total_deaths = df.sum(axis=1)

# Selezionare i 7 paesi con più morti
top_7 = total_deaths.nlargest(7)  # 7 paesi con più morti

# Filtrare il DataFrame per i paesi selezionati
df_selected = df.loc[top_7.index]

# Creazione della figura (figsize) separata per il grafico
plt.figure(figsize=(12, 6))

# Definiamo i colori manualmente per ogni paese
# Assicurati che l'ordine dei colori corrisponda a quello dei paesi
labels_paesi = ["Turchia", "Francia", "Germania", "Italia", "Polonia", "Spagna", "Romania"]
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2']  # Colori a tua scelta

# Creazione del grafico a linee con i dati reali, usando i colori specificati
df_selected.T.plot(kind="line", marker='o', alpha=0.8, figsize=(12, 6), color=colors)

# Aggiunta del titolo e delle etichette degli assi
plt.title("Numero di morti per Paese negli anni", fontweight='bold')
plt.xlabel("Anno")
plt.ylabel("Numero di morti")

# Personalizzazione della legenda e della griglia
plt.legend(title="Paese", loc="upper right")

# Personalizzazione della legenda con etichette personalizzate
plt.legend(title="Legenda", loc="upper right", labels=labels_paesi)

# Visualizzazione del grafico
plt.show()