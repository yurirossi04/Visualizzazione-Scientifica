import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Caricamento del dataset
file_path = "File csv/DCIS_INCIDENTISTR1_03022025132214442.csv"
df = pd.read_csv(file_path)

# Rimuove eventuali spazi nei nomi delle colonne
df.columns = df.columns.str.strip()

# Filtra il dataset per le 4 regioni (Lombardia, Lazio, Veneto, Campania)
regions_of_interest = ['Lombardia', 'Lazio', 'Campania', 'Veneto', 'Sicilia', 'Emilia-Romagna']
df_filtered = df[df['Territorio'].isin(regions_of_interest)]

# Escludi i valori "galleria" dalla colonna "Intersezione" e "totale" dalla colonna "Natura dell incidente"
df_filtered = df_filtered[~df_filtered['Intersezione'].isin(['galleria', 'totale', 'passaggio a livello'])]
df_filtered = df_filtered[~df_filtered['Natura dell incidente'].isin(['totale'])]

# Crea un set di ticks comuni per tutti i grafici
common_y_ticks = ['Rettilineo', 'Incrocio', 'Curva', 'Rotatoria', 'Altro', 'Veicolo e veicolo', 'Veicoolo e pedone', 'Veicolo isolato']  # Personalizza queste etichette a piacere

# Crea un grafico a barre orizzontali per ogni regione
fig, axs = plt.subplots(2, 3, figsize=(16, 9))  # 2x3 grafici
axs = axs.flatten()  # Per facilitare l'indicizzazione degli assi

# Colori personalizzati
color_intersezione = 'skyblue'
color_natura = 'orange'

# Crea i grafici a barre orizzontali per ciascuna delle 4 regioni
for i, region in enumerate(regions_of_interest):
    # Filtra i dati per la regione specifica
    region_data = df_filtered[df_filtered['Territorio'] == region]
    
    # Conta le occorrenze di ciascuna tipologia di intersezione
    intersezione_counts = region_data['Intersezione'].value_counts()

    # Conta le occorrenze di ciascuna tipologia nella colonna "Natura dell'incidente"
    natura_counts = region_data['Natura dell incidente'].value_counts()
    
    # Crea il grafico a barre orizzontali per la tipologia di intersezione
    axs[i].barh(intersezione_counts.index, intersezione_counts.values, color='skyblue', label='Intersezione', height=0.5)

    # Aggiungi le barre per "Natura dell'incidente"
    axs[i].barh(natura_counts.index, natura_counts.values, color='orange', alpha=0.6, label='Natura dell incidente', height=0.5)

    # Aggiungi titoli e miglioramenti grafici per ogni grafico
    axs[i].set_title(f"{region}", fontsize=14)  # Solo il nome della regione nel titolo
    axs[i].set_xlabel('Occorrenze (in migliaia)', fontsize=12)
    
    # Imposta l'asse X a 10k come massimo per ogni grafico
    axs[i].set_xlim(0, 10000)
    
    # Modifica l'asse x per visualizzare i valori in migliaia
    axs[i].set_xticklabels([f'{x/1000:.1f}K' for x in axs[i].get_xticks()])

    # Imposta i tick e le etichette personalizzate per l'asse Y (uguali per tutti i grafici)
    axs[i].set_yticks(range(len(common_y_ticks)))  # Assegna la stessa posizione dei ticks
    axs[i].set_yticklabels(common_y_ticks)  # Applica le stesse etichette

# Creazione della legenda personalizzata
handles = [
    mpatches.Patch(color=color_intersezione, label="Incidenti in intersezioni"),
    mpatches.Patch(color=color_natura, alpha=0.6, label="Incidenti per tipologia")
]

fig.legend(handles=handles, loc='lower center', ncol=2, fontsize=12, frameon=False)

# **Aggiunta del titolo principale**
fig.suptitle("Incidenti nelle regioni più popolose", fontsize=16, fontweight='bold')

# Migliora la disposizione del layout per evitare sovrapposizioni
plt.tight_layout(rect=[0, 0.05, 1, 0.95])  # Modifica rect per lasciare spazio al titolo

# Mostra il grafico
plt.show()
