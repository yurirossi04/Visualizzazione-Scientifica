import pandas as pd
import matplotlib.pyplot as plt

# Caricare i dati dal CSV
df = pd.read_csv("File csv/DCIS_INCIDENTISTR1_03022025132214442.csv")

# Filtrare le righe dove "Localizzazione dell incidente" non è "totale"
df_filtrato = df[df['Localizzazione dell incidente'] != 'totale']

# Contare le tipologie di strade
tipologie_strade = df_filtrato['Localizzazione dell incidente'].value_counts()

# Definizione di una palette di colori personalizzati
colori_personalizzati = ['#354674', '#6C91C2', '#C3C9E9']

# Creare il grafico a torta
plt.figure(figsize=(8,8))
tipologie_strade.plot(kind='pie', autopct='%1.1f%%', colors=colori_personalizzati, startangle=90, legend=False)
plt.title('Percentuale degli Incidenti per Tipologia di Strada', fontweight='bold')

# Mostrare il grafico
plt.ylabel('')  # Rimuovere l'etichetta sull'asse y
plt.tight_layout()
plt.show()
