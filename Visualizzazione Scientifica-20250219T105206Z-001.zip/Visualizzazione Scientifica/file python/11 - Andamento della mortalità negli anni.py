import pandas as pd
import matplotlib.pyplot as plt

# Prendere il dataframe dal csv
df = pd.read_csv("File csv/incidenti_stradali_con_lesioni.csv")

# Convertire le colonne di percentuali in formato numerico (gestendo eventuali valori non numerici)
df['Var % annua dei morti'] = pd.to_numeric(df['Var % annua dei morti'], errors='coerce')
df['Var % morti vs 2001'] = pd.to_numeric(df['Var % morti vs 2001'], errors='coerce')
df['Var % morti vs 2010'] = pd.to_numeric(df['Var % morti vs 2010'], errors='coerce')

# Rimuovere le righe con valori NaN nelle colonne di interesse
df_clean = df.dropna(subset=['Var % annua dei morti', 'Var % morti vs 2001', 'Var % morti vs 2010'])

# Creare un grafico a linee per le percentuali
fig, ax = plt.subplots(figsize=(10,6))

# Tracciare le linee per le tre colonne di percentuali
ax.plot(df_clean['Anno'], df_clean['Var % annua dei morti'], label='Var % annua dei morti', color='tab:blue', marker='o', linestyle='-', linewidth=2)
ax.plot(df_clean['Anno'], df_clean['Var % morti vs 2001'], label='Var % morti vs 2001', color='tab:green', marker='o', linestyle='-', linewidth=2)
ax.plot(df_clean['Anno'], df_clean['Var % morti vs 2010'], label='Var % morti vs 2010', color='tab:orange', marker='o', linestyle='-', linewidth=2)

# Aggiungere la linea verticale per evidenziare l'anno 2020
ax.axvline(x=2020, color='red', linestyle='--', linewidth=1, label='Anno 2020')

# Aggiungere una scritta vicino alla linea del 2020
ax.text(2020, 40, '  Quarantena\n    Covid-19', color='red', fontsize=10, verticalalignment='bottom', horizontalalignment='left')

# Impostare etichette e titolo
ax.set_ylabel('Var %\nMorti', rotation=0)
ax.set_title('Andamento delle Variazioni Percentuali dei Morti', fontweight='bold')

# Impostare i limiti dell'asse Y da -100% a 100% con lo zero al centro
ax.set_ylim(-100, 100)

# Aggiungere i tick dell'asse X con gli anni
ax.set_xticks(df_clean['Anno'])  # Mettere i tick per ogni anno
ax.set_xticklabels(df_clean['Anno'], rotation=0)  # Aggiungere etichette degli anni

# Aggiungere legende
ax.legend()

# Mostrare il grafico
plt.show()
